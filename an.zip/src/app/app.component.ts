import { Component, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

import { HealthMonitorService } from './health-monitor.service';
import { OfflineDialogComponent } from './offline-dialog.component';

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <main>
      <h1>接続監視サンプル</h1>
      <input type="text" placeholder="入力欄">
      <button type="button">ボタン</button>
    </main>
  `,
  styles: `
    main { padding: 16px; }
  `,
})
export class AppComponent {
  private readonly dialog = inject(MatDialog);
  private dialogRef: MatDialogRef<OfflineDialogComponent> | null = null;

  constructor() {
    inject(HealthMonitorService)
      .watch()
      .pipe(takeUntilDestroyed())
      .subscribe((alive) => (alive ? this.closeDialog() : this.openDialog()));
  }

  private openDialog(): void {
    if (this.dialogRef) return; // 多重表示を防ぐ

    this.dialogRef = this.dialog.open(OfflineDialogComponent, {
      disableClose: true, // Escキーと背景クリックで閉じない
      closeOnNavigation: false, // 戻る操作などで閉じない
      role: 'alertdialog',
      width: '360px',
    });
  }

  private closeDialog(): void {
    this.dialogRef?.close();
    this.dialogRef = null;
  }
}
