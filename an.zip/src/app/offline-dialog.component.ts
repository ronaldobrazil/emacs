import { ChangeDetectionStrategy, Component } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-offline-dialog',
  standalone: true,
  imports: [MatDialogModule, MatProgressSpinnerModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  // 閉じるボタンは置かない
  template: `
    <h2 mat-dialog-title>サーバーから応答がありません</h2>
    <mat-dialog-content>
      <p>再接続を試みています。しばらくお待ちください。</p>
      <mat-spinner class="spinner" diameter="32" aria-label="再接続中" />
    </mat-dialog-content>
  `,
  styles: `
    .spinner { margin: 0 auto; }
  `,
})
export class OfflineDialogComponent {}
