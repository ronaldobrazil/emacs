import { DOCUMENT } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import {
  Observable,
  catchError,
  exhaustMap,
  filter,
  fromEvent,
  map,
  merge,
  of,
  timeout,
  timer,
} from 'rxjs';

// 監視先URL(実際のAPIに合わせて変更する。例: '/api/health')
const HEALTH_URL = '/';
// 送信周期
const INTERVAL_MS = 10_000;
// この時間内に応答がなければ「応答なし」と判定(周期より短くする)
const TIMEOUT_MS = 5_000;

@Injectable({ providedIn: 'root' })
export class HealthMonitorService {
  private readonly http = inject(HttpClient);
  private readonly document = inject(DOCUMENT);

  /** 購読している間、監視を続けて結果(true: 応答あり)を流す */
  watch(): Observable<boolean> {
    // タブが再び表示されたら、次の周期を待たずに確認する
    const visible$ = fromEvent(this.document, 'visibilitychange').pipe(
      filter(() => this.document.visibilityState === 'visible'),
    );

    return merge(timer(0, INTERVAL_MS), visible$).pipe(
      exhaustMap(() => this.check()), // 実行中は次を送らない
    );
  }

  private check(): Observable<boolean> {
    return this.http
      .get(HEALTH_URL, {
        responseType: 'text',
        params: { t: Date.now() }, // キャッシュからの応答を防ぐ
      })
      .pipe(
        timeout(TIMEOUT_MS), // 時間切れでリクエストは中断される
        map(() => true),
        // check() の内側で捕捉するので、失敗しても監視は止まらない
        catchError(() => of(false)),
      );
  }
}
