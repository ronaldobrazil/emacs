# Angular Material connection monitor

## Run

From the repository root, enter the Nix development shell and start the app:

```sh
nix develop
cd webangularmat
npm ci
npm start
```

The app sends `GET /api/health` immediately and then every 10 seconds. Edit
`healthUrl` in `src/app/app.component.ts` to use a different endpoint. Any
successful HTTP response clears the dialog; network errors, non-success HTTP
statuses, and responses taking longer than 9 seconds show it.

The `MatDialog` uses `disableClose: true` and `closeOnNavigation: false`.
While the error is active, in-page F5/Ctrl+R/Cmd+R shortcuts are also blocked.
A webpage cannot reliably prevent reloads triggered by browser controls,
closing the tab, or leaving the page.
