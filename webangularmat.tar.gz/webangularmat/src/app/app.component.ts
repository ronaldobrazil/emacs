import { HttpClient } from '@angular/common/http';
import {
  Component,
  HostListener,
  OnDestroy,
  OnInit
} from '@angular/core';
import {
  MatDialog,
  MatDialogModule,
  MatDialogRef
} from '@angular/material/dialog';
import { catchError, exhaustMap, map, of, Subscription, timeout, timer } from 'rxjs';
import { ConnectionErrorDialogComponent } from './connection-error-dialog.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [MatDialogModule],
  template: `
    <main>
      <h1>通信状態監視</h1>
      <p>監視先: <code>{{ healthUrl }}</code></p>
      <p>
        状態:
        <strong [class.error]="isConnectionError">
          {{ isConnectionError ? '通信異常' : '応答確認中' }}
        </strong>
      </p>
      <p>10秒間隔でサーバーの応答を確認します。</p>
    </main>
  `,
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit, OnDestroy {
  readonly healthUrl = '/api/health';
  isConnectionError = false;

  private pollingSubscription?: Subscription;
  private dialogRef?: MatDialogRef<ConnectionErrorDialogComponent>;

  constructor(
    private readonly http: HttpClient,
    private readonly dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.pollingSubscription = timer(0, 10_000)
      .pipe(
        exhaustMap(() =>
          this.http.get(this.healthUrl, { responseType: 'text' }).pipe(
            timeout({ first: 9_000 }),
            map(() => true),
            catchError(() => of(false))
          )
        )
      )
      .subscribe((isHealthy) => this.updateConnectionState(isHealthy));
  }

  ngOnDestroy(): void {
    this.pollingSubscription?.unsubscribe();
    this.dialogRef?.close();
  }

  @HostListener('window:keydown', ['$event'])
  preventReloadDuringOutage(event: KeyboardEvent): void {
    if (!this.isConnectionError) {
      return;
    }

    const reloadShortcut =
      event.key === 'F5' ||
      ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'r');

    if (reloadShortcut) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }

  private updateConnectionState(isHealthy: boolean): void {
    this.isConnectionError = !isHealthy;

    if (!isHealthy && !this.dialogRef) {
      const dialogRef = this.dialog.open(ConnectionErrorDialogComponent, {
        ariaLabelledBy: 'connection-error-title',
        disableClose: true,
        hasBackdrop: true,
        closeOnNavigation: false
      });

      this.dialogRef = dialogRef;
      dialogRef.afterClosed().subscribe(() => {
        if (this.dialogRef === dialogRef) {
          this.dialogRef = undefined;
        }
      });
    } else if (isHealthy && this.dialogRef) {
      const dialogRef = this.dialogRef;
      this.dialogRef = undefined;
      dialogRef.close();
    }
  }
}
