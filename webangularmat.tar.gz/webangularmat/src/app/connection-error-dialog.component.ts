import { Component } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';

@Component({
  selector: 'app-connection-error-dialog',
  standalone: true,
  imports: [MatDialogModule],
  template: `
    <h2 mat-dialog-title id="connection-error-title">通信異常</h2>
    <mat-dialog-content>
      <p>サーバーから正常な応答を受信できません。</p>
      <p>通信が回復するまで、自動再試行をお待ちください。</p>
    </mat-dialog-content>
  `
})
export class ConnectionErrorDialogComponent {}
