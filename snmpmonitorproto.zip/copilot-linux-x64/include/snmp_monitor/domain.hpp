#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace snmp_monitor {

enum class FaultLevel {
    minor,
    major,
};

struct NodeConfig {
    std::string address;
    std::string community;
};

struct MibDefinition {
    std::string key;
    std::string oid;
    FaultLevel fault_level;
};

struct MonitorConfig {
    std::vector<NodeConfig> nodes;
    std::vector<MibDefinition> mibs;
};

struct MibReading {
    std::string key;
    std::string oid;
    std::optional<std::string> value;
    FaultLevel fault_level;
    std::string status;
};

struct NodeSnapshot {
    std::string address;
    std::string status;
    std::int64_t last_checked_unix;
    std::vector<MibReading> readings;
    std::optional<std::string> error;
};

std::string to_string(FaultLevel level);

}  // namespace snmp_monitor
