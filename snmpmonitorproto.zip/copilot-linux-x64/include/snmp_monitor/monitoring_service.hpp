#pragma once

#include "snmp_monitor/ports.hpp"

#include <chrono>
#include <csignal>

namespace snmp_monitor {

class MonitoringService {
public:
    MonitoringService(const ISnmpClient& snmp_client,
                      ISnapshotPublisher& publisher,
                      const MonitorConfig& config);

    void poll_once();
    void run(const volatile std::sig_atomic_t& running,
             std::chrono::seconds interval);

private:
    const ISnmpClient& snmp_client_;
    ISnapshotPublisher& publisher_;
    const MonitorConfig& config_;
};

}  // namespace snmp_monitor
