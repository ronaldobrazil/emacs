#pragma once

#include "snmp_monitor/ports.hpp"

#include <string>

namespace snmp_monitor {

class PosixSharedMemoryPublisher final : public ISnapshotPublisher {
public:
    explicit PosixSharedMemoryPublisher(std::string name);
    ~PosixSharedMemoryPublisher() override;

    PosixSharedMemoryPublisher(const PosixSharedMemoryPublisher&) = delete;
    PosixSharedMemoryPublisher& operator=(const PosixSharedMemoryPublisher&) = delete;

    void publish(const std::vector<NodeSnapshot>& snapshot) override;

private:
    int fd_ = -1;
};

}  // namespace snmp_monitor
