#pragma once

#include "snmp_monitor/ports.hpp"

namespace snmp_monitor {

class NetSnmpClient final : public ISnmpClient {
public:
    NodeSnapshot poll(const NodeConfig& node,
                      const std::vector<MibDefinition>& mibs) const override;
};

}  // namespace snmp_monitor
