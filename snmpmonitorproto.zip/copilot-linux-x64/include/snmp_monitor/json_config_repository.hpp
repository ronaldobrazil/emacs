#pragma once

#include "snmp_monitor/ports.hpp"

namespace snmp_monitor {

class JsonConfigRepository final : public IConfigRepository {
public:
    MonitorConfig load(const std::string& nodes_path,
                       const std::string& mibs_path) const override;
};

}  // namespace snmp_monitor
