#pragma once

#include "snmp_monitor/domain.hpp"

#include <string>
#include <vector>

namespace snmp_monitor {

class IConfigRepository {
public:
    virtual ~IConfigRepository() = default;
    virtual MonitorConfig load(const std::string& nodes_path,
                               const std::string& mibs_path) const = 0;
};

class ISnmpClient {
public:
    virtual ~ISnmpClient() = default;
    virtual NodeSnapshot poll(const NodeConfig& node,
                              const std::vector<MibDefinition>& mibs) const = 0;
};

class ISnapshotPublisher {
public:
    virtual ~ISnapshotPublisher() = default;
    virtual void publish(const std::vector<NodeSnapshot>& snapshot) = 0;
};

}  // namespace snmp_monitor
