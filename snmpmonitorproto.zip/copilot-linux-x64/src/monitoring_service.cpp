#include "snmp_monitor/monitoring_service.hpp"

#include <chrono>
#include <future>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace snmp_monitor {
namespace {

std::int64_t unix_time_now() {
    return std::chrono::duration_cast<std::chrono::seconds>(
               std::chrono::system_clock::now().time_since_epoch())
        .count();
}

NodeSnapshot unexpected_failure(const NodeConfig& node,
                                const std::vector<MibDefinition>& mibs,
                                const std::string& error) {
    NodeSnapshot snapshot{node.address, "minor", unix_time_now(), {}, error};
    snapshot.readings.reserve(mibs.size());
    bool major = false;
    for (const auto& mib : mibs) {
        const std::string level = to_string(mib.fault_level);
        major = major || mib.fault_level == FaultLevel::major;
        snapshot.readings.push_back(
            {mib.key, mib.oid, std::nullopt, mib.fault_level, level});
    }
    if (major) {
        snapshot.status = "major";
    }
    return snapshot;
}

}  // namespace

MonitoringService::MonitoringService(const ISnmpClient& snmp_client,
                                     ISnapshotPublisher& publisher,
                                     const MonitorConfig& config)
    : snmp_client_(snmp_client), publisher_(publisher), config_(config) {}

void MonitoringService::poll_once() {
    std::vector<std::future<NodeSnapshot>> futures;
    futures.reserve(config_.nodes.size());
    for (const auto& node : config_.nodes) {
        const NodeConfig node_copy = node;
        futures.push_back(std::async(
            std::launch::async,
            [this, node_copy]() {
                return snmp_client_.poll(node_copy, config_.mibs);
            }));
    }

    std::vector<NodeSnapshot> snapshot;
    snapshot.reserve(config_.nodes.size());
    for (std::size_t i = 0; i < futures.size(); ++i) {
        try {
            snapshot.push_back(futures[i].get());
        } catch (const std::exception& error) {
            snapshot.push_back(
                unexpected_failure(config_.nodes[i], config_.mibs, error.what()));
        } catch (...) {
            snapshot.push_back(unexpected_failure(
                config_.nodes[i], config_.mibs, "unknown polling error"));
        }
    }
    publisher_.publish(snapshot);
    std::cout << "Published " << snapshot.size() << " node snapshots\n";
}

void MonitoringService::run(const volatile std::sig_atomic_t& running,
                            std::chrono::seconds interval) {
    auto next_poll = std::chrono::steady_clock::now();
    while (running != 0) {
        poll_once();
        next_poll += interval;
        const auto now = std::chrono::steady_clock::now();
        while (next_poll <= now) {
            next_poll += interval;
        }
        std::this_thread::sleep_until(next_poll);
    }
}

}  // namespace snmp_monitor
