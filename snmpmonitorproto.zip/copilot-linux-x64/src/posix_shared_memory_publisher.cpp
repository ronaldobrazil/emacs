#include "snmp_monitor/posix_shared_memory_publisher.hpp"

#include <fcntl.h>
#include <json-c/json.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>
#include <algorithm>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>

namespace snmp_monitor {
namespace {

using JsonOwner = std::unique_ptr<json_object, decltype(&json_object_put)>;

[[noreturn]] void throw_errno(const std::string& operation) {
    throw std::runtime_error(operation + ": " + std::strerror(errno));
}

class WriteLock {
public:
    explicit WriteLock(int fd) : fd_(fd) {
        struct flock lock {};
        lock.l_type = F_WRLCK;
        lock.l_whence = SEEK_SET;
        while (fcntl(fd_, F_SETLKW, &lock) == -1) {
            if (errno != EINTR) {
                throw_errno("fcntl write lock");
            }
        }
    }

    ~WriteLock() {
        struct flock lock {};
        lock.l_type = F_UNLCK;
        lock.l_whence = SEEK_SET;
        fcntl(fd_, F_SETLK, &lock);
    }

    WriteLock(const WriteLock&) = delete;
    WriteLock& operator=(const WriteLock&) = delete;

private:
    int fd_;
};

JsonOwner make_object() {
    JsonOwner object(json_object_new_object(), &json_object_put);
    if (!object) {
        throw std::runtime_error("unable to allocate JSON object");
    }
    return object;
}

JsonOwner make_array() {
    JsonOwner array(json_object_new_array(), &json_object_put);
    if (!array) {
        throw std::runtime_error("unable to allocate JSON array");
    }
    return array;
}

void add(json_object* object, const char* key, JsonOwner value) {
    if (json_object_object_add(object, key, value.get()) != 0) {
        throw std::runtime_error(std::string("unable to serialize field ") +
                                 key);
    }
    value.release();
}

void add_string(json_object* object, const char* key,
                const std::string& value) {
    JsonOwner string(json_object_new_string_len(value.data(),
                                                 static_cast<int>(value.size())),
                     &json_object_put);
    if (!string) {
        throw std::runtime_error("unable to allocate JSON string");
    }
    add(object, key, std::move(string));
}

void add_number(json_object* object, const char* key, std::int64_t value) {
    JsonOwner number(json_object_new_int64(value), &json_object_put);
    if (!number) {
        throw std::runtime_error("unable to allocate JSON number");
    }
    add(object, key, std::move(number));
}

std::string serialize(const std::vector<NodeSnapshot>& snapshot) {
    JsonOwner root = make_object();
    add(root.get(), "schema_version",
        JsonOwner(json_object_new_int(1), &json_object_put));
    JsonOwner nodes = make_array();
    for (const auto& node : snapshot) {
        JsonOwner node_object = make_object();
        add_string(node_object.get(), "address", node.address);
        add_string(node_object.get(), "status", node.status);
        add_number(node_object.get(), "last_checked_unix",
                   node.last_checked_unix);
        if (node.error.has_value()) {
            add_string(node_object.get(), "error", *node.error);
        } else {
            add(node_object.get(), "error",
                JsonOwner(json_object_new_null(), &json_object_put));
        }

        JsonOwner values = make_object();
        for (const auto& reading : node.readings) {
            JsonOwner value_object = make_object();
            if (reading.value.has_value()) {
                add_string(value_object.get(), "value", *reading.value);
            } else {
                add(value_object.get(), "value",
                    JsonOwner(json_object_new_null(), &json_object_put));
            }
            add_string(value_object.get(), "oid", reading.oid);
            add_string(value_object.get(), "fault_level",
                       to_string(reading.fault_level));
            add_string(value_object.get(), "status", reading.status);
            add(values.get(), reading.key.c_str(), std::move(value_object));
        }
        add(node_object.get(), "values", std::move(values));
        if (json_object_array_add(nodes.get(), node_object.get()) != 0) {
            throw std::runtime_error("unable to append node to JSON output");
        }
        node_object.release();
    }
    add(root.get(), "nodes", std::move(nodes));

    const char* text =
        json_object_to_json_string_ext(root.get(), JSON_C_TO_STRING_PLAIN);
    if (text == nullptr) {
        throw std::runtime_error("unable to encode shared-memory JSON");
    }
    return text;
}

}  // namespace

PosixSharedMemoryPublisher::PosixSharedMemoryPublisher(std::string name) {
    if (name.size() < 2 || name.front() != '/' ||
        name.find('/', 1) != std::string::npos) {
        throw std::invalid_argument(
            "shared-memory name must start with '/' and contain no other '/'");
    }
    fd_ = shm_open(name.c_str(), O_CREAT | O_RDWR, 0660);
    if (fd_ == -1) {
        throw_errno("shm_open");
    }
    try {
        WriteLock lock(fd_);
        struct stat status {};
        if (fstat(fd_, &status) == -1) {
            throw_errno("fstat shared memory");
        }
        if (status.st_size == 0 && ftruncate(fd_, 4096) == -1) {
            throw_errno("initialize shared memory");
        }
    } catch (...) {
        close(fd_);
        fd_ = -1;
        throw;
    }
}

PosixSharedMemoryPublisher::~PosixSharedMemoryPublisher() {
    if (fd_ != -1) {
        close(fd_);
    }
}

void PosixSharedMemoryPublisher::publish(
    const std::vector<NodeSnapshot>& snapshot) {
    const std::string json = serialize(snapshot);
    if (json.size() >=
        static_cast<std::size_t>(std::numeric_limits<off_t>::max())) {
        throw std::runtime_error("shared-memory JSON is too large");
    }

    WriteLock lock(fd_);
    struct stat status {};
    if (fstat(fd_, &status) == -1) {
        throw_errno("fstat shared memory");
    }
    const std::size_t required = json.size() + 1;
    std::size_t capacity = static_cast<std::size_t>(status.st_size);
    if (capacity < required) {
        capacity = std::max<std::size_t>(capacity, 4096);
        while (capacity < required) {
            if (capacity >
                static_cast<std::size_t>(std::numeric_limits<off_t>::max()) /
                    2) {
                capacity = required;
                break;
            }
            capacity *= 2;
        }
        if (ftruncate(fd_, static_cast<off_t>(capacity)) == -1) {
            throw_errno("grow shared memory");
        }
    }

    void* memory = mmap(nullptr, capacity, PROT_READ | PROT_WRITE, MAP_SHARED,
                        fd_, 0);
    if (memory == MAP_FAILED) {
        throw_errno("mmap shared memory");
    }
    std::memcpy(memory, json.data(), json.size());
    static_cast<char*>(memory)[json.size()] = '\0';
    if (munmap(memory, capacity) == -1) {
        throw_errno("munmap shared memory");
    }
}

}  // namespace snmp_monitor
