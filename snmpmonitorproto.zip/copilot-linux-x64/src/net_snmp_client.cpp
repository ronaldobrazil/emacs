#include "snmp_monitor/net_snmp_client.hpp"

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>

#include <array>
#include <chrono>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace snmp_monitor {
namespace {

class SessionHandle {
public:
    explicit SessionHandle(void* handle) : handle_(handle) {}
    ~SessionHandle() {
        if (handle_ != nullptr) {
            snmp_sess_close(handle_);
        }
    }

    SessionHandle(const SessionHandle&) = delete;
    SessionHandle& operator=(const SessionHandle&) = delete;

    void* get() const { return handle_; }

private:
    void* handle_;
};

struct ParsedOid {
    std::vector<oid> arcs;
};

ParsedOid parse_oid(const std::string& text) {
    std::array<oid, MAX_OID_LEN> parsed{};
    std::size_t length = parsed.size();
    const std::string normalized =
        (!text.empty() && text.front() == '.') ? text : "." + text;
    if (snmp_parse_oid(normalized.c_str(), parsed.data(), &length) == 0) {
        throw std::runtime_error("invalid OID: " + text);
    }
    return {{parsed.begin(), parsed.begin() + static_cast<std::ptrdiff_t>(length)}};
}

bool has_prefix(const netsnmp_variable_list* variable,
                const ParsedOid& requested) {
    return variable != nullptr &&
           variable->name_length >= requested.arcs.size() &&
           snmp_oid_compare(variable->name, requested.arcs.size(),
                            requested.arcs.data(),
                            requested.arcs.size()) == 0;
}

std::string response_error(void* handle, int status) {
    if (status == STAT_TIMEOUT) {
        return "SNMP request timed out";
    }
    int system_error = 0;
    int snmp_error = 0;
    char* detail = nullptr;
    snmp_sess_error(handle, &system_error, &snmp_error, &detail);
    std::string message = detail != nullptr ? detail : "SNMP request failed";
    SNMP_FREE(detail);
    return message;
}

std::string level_status(FaultLevel level) {
    return to_string(level);
}

std::int64_t unix_time_now() {
    return std::chrono::duration_cast<std::chrono::seconds>(
               std::chrono::system_clock::now().time_since_epoch())
        .count();
}

NodeSnapshot failed_snapshot(const NodeConfig& node,
                             const std::vector<MibDefinition>& mibs,
                             const std::string& error) {
    NodeSnapshot snapshot{node.address, "down", unix_time_now(), {}, error};
    snapshot.readings.reserve(mibs.size());
    bool major = false;
    for (const auto& mib : mibs) {
        snapshot.readings.push_back(
            {mib.key, mib.oid, std::nullopt, mib.fault_level,
             level_status(mib.fault_level)});
        major = major || mib.fault_level == FaultLevel::major;
    }
    snapshot.status = major ? "major" : "minor";
    return snapshot;
}

}  // namespace

std::string to_string(FaultLevel level) {
    return level == FaultLevel::major ? "major" : "minor";
}

NodeSnapshot NetSnmpClient::poll(
    const NodeConfig& node, const std::vector<MibDefinition>& mibs) const {
    try {
        if (mibs.empty() ||
            mibs.size() > static_cast<std::size_t>(
                              std::numeric_limits<int>::max())) {
            throw std::runtime_error("invalid number of MIB OIDs");
        }

        std::vector<ParsedOid> parsed_oids;
        parsed_oids.reserve(mibs.size());
        for (const auto& mib : mibs) {
            parsed_oids.push_back(parse_oid(mib.oid));
        }

        netsnmp_session session{};
        snmp_sess_init(&session);
        session.peername = const_cast<char*>(node.address.c_str());
        session.version = SNMP_VERSION_2c;
        session.community = reinterpret_cast<u_char*>(
            const_cast<char*>(node.community.c_str()));
        session.community_len = node.community.size();
        session.timeout = 1'000'000;
        session.retries = 0;

        SessionHandle handle(snmp_sess_open(&session));
        if (handle.get() == nullptr) {
            return failed_snapshot(node, mibs, "unable to open SNMP session");
        }

        netsnmp_pdu* request = snmp_pdu_create(SNMP_MSG_GETBULK);
        if (request == nullptr) {
            return failed_snapshot(node, mibs,
                                   "unable to allocate SNMP request");
        }
        request->non_repeaters = static_cast<int>(mibs.size());
        request->max_repetitions = 1;
        for (const auto& parsed : parsed_oids) {
            if (snmp_add_null_var(request, parsed.arcs.data(),
                                  parsed.arcs.size()) == nullptr) {
                snmp_free_pdu(request);
                return failed_snapshot(node, mibs,
                                       "unable to add OID to SNMP request");
            }
        }

        netsnmp_pdu* response = nullptr;
        const int request_status =
            snmp_sess_synch_response(handle.get(), request, &response);
        if (request_status != STAT_SUCCESS || response == nullptr) {
            if (response != nullptr) {
                snmp_free_pdu(response);
            }
            return failed_snapshot(
                node, mibs, response_error(handle.get(), request_status));
        }
        if (response->errstat != SNMP_ERR_NOERROR) {
            const std::string error =
                "SNMP agent returned error status " +
                std::to_string(response->errstat);
            snmp_free_pdu(response);
            return failed_snapshot(node, mibs, error);
        }

        NodeSnapshot snapshot{node.address, "normal", unix_time_now(), {}, {}};
        snapshot.readings.reserve(mibs.size());
        const netsnmp_variable_list* variable = response->variables;
        bool had_failure = false;
        bool had_major = false;
        for (std::size_t i = 0; i < mibs.size(); ++i) {
            const auto& mib = mibs[i];
            std::optional<std::string> value;
            std::string status = "normal";
            if (variable == nullptr || !has_prefix(variable, parsed_oids[i]) ||
                variable->type == SNMP_NOSUCHOBJECT ||
                variable->type == SNMP_NOSUCHINSTANCE ||
                variable->type == SNMP_ENDOFMIBVIEW) {
                status = level_status(mib.fault_level);
            } else {
                std::array<char, 4096> text{};
                const int length =
                    snprint_value(text.data(), text.size(), variable->name,
                                  variable->name_length, variable);
                if (length < 0 ||
                    static_cast<std::size_t>(length) >= text.size()) {
                    status = level_status(mib.fault_level);
                } else {
                    value = std::string(text.data(),
                                        static_cast<std::size_t>(length));
                }
            }
            if (!value.has_value()) {
                had_failure = true;
                had_major = had_major || mib.fault_level == FaultLevel::major;
            }
            snapshot.readings.push_back(
                {mib.key, mib.oid, std::move(value), mib.fault_level, status});
            if (variable != nullptr) {
                variable = variable->next_variable;
            }
        }
        snmp_free_pdu(response);
        if (had_failure) {
            snapshot.status = had_major ? "major" : "minor";
            snapshot.error = "one or more MIB values are unavailable";
        }
        return snapshot;
    } catch (const std::exception& error) {
        return failed_snapshot(node, mibs, error.what());
    }
}

}  // namespace snmp_monitor
