#include "snmp_monitor/json_config_repository.hpp"
#include "snmp_monitor/monitoring_service.hpp"
#include "snmp_monitor/net_snmp_client.hpp"
#include "snmp_monitor/posix_shared_memory_publisher.hpp"

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/library/default_store.h>

#include <csignal>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {

constexpr char kDefaultSharedMemory[] = "/snmp_v2c_monitor";
volatile std::sig_atomic_t g_running = 1;

void handle_signal(int) {
    g_running = 0;
}

class SnmpRuntime {
public:
    SnmpRuntime() {
        SOCK_STARTUP;
        if (netsnmp_ds_set_boolean(
                NETSNMP_DS_LIBRARY_ID,
                NETSNMP_DS_LIB_DISABLE_PERSISTENT_LOAD, 1) != SNMPERR_SUCCESS ||
            netsnmp_ds_set_boolean(
                NETSNMP_DS_LIBRARY_ID,
                NETSNMP_DS_LIB_DISABLE_PERSISTENT_SAVE, 1) != SNMPERR_SUCCESS) {
            SOCK_CLEANUP;
            throw std::runtime_error("unable to configure Net-SNMP runtime");
        }
        init_snmp("snmp_v2c_monitor");
    }

    ~SnmpRuntime() {
        snmp_shutdown("snmp_v2c_monitor");
        SOCK_CLEANUP;
    }

    SnmpRuntime(const SnmpRuntime&) = delete;
    SnmpRuntime& operator=(const SnmpRuntime&) = delete;
};

}  // namespace

int main(int argc, char* argv[]) {
    if (argc < 3 || argc > 4) {
        std::cerr << "Usage: " << argv[0]
                  << " <nodes.json> <mibs.json> [shared-memory-name]\n"
                  << "Default shared-memory-name: " << kDefaultSharedMemory
                  << '\n';
        return 2;
    }

    try {
        snmp_monitor::JsonConfigRepository config_repository;
        const auto config = config_repository.load(argv[1], argv[2]);
        const std::string shared_memory_name =
            argc == 4 ? argv[3] : kDefaultSharedMemory;
        snmp_monitor::PosixSharedMemoryPublisher publisher(
            shared_memory_name);
        snmp_monitor::NetSnmpClient snmp_client;
        snmp_monitor::MonitoringService service(snmp_client, publisher, config);

        SnmpRuntime snmp_runtime;
        std::signal(SIGINT, handle_signal);
        std::signal(SIGTERM, handle_signal);
        service.run(g_running, std::chrono::seconds(5));
    } catch (const std::exception& error) {
        std::cerr << "Fatal error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
