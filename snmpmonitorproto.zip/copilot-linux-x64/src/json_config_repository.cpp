#include "snmp_monitor/json_config_repository.hpp"

#include <arpa/inet.h>
#include <json-c/json.h>

#include <charconv>
#include <memory>
#include <set>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>

namespace snmp_monitor {
namespace {

using JsonOwner = std::unique_ptr<json_object, decltype(&json_object_put)>;

std::string required_string(json_object* object, const char* field,
                            const std::string& context) {
    json_object* value = nullptr;
    if (!json_object_object_get_ex(object, field, &value) ||
        json_object_get_type(value) != json_type_string) {
        throw std::runtime_error(context + ": expected string field '" +
                                 field + "'");
    }
    return json_object_get_string(value);
}

json_object* required_array(json_object* object, const char* field,
                            const std::string& context) {
    json_object* value = nullptr;
    if (!json_object_object_get_ex(object, field, &value) ||
        json_object_get_type(value) != json_type_array) {
        throw std::runtime_error(context + ": expected array field '" +
                                 field + "'");
    }
    return value;
}

JsonOwner read_json(const std::string& path) {
    JsonOwner root(json_object_from_file(path.c_str()), &json_object_put);
    if (!root || json_object_get_type(root.get()) != json_type_object) {
        const char* detail = json_util_get_last_err();
        throw std::runtime_error("Unable to read JSON object from '" + path +
                                 "'" + (detail == nullptr ? "" :
                                        std::string(": ") + detail));
    }
    return root;
}

void validate_ipv4(const std::string& address, const std::string& context) {
    in_addr parsed{};
    if (inet_pton(AF_INET, address.c_str(), &parsed) != 1) {
        throw std::runtime_error(context + ": invalid IPv4 address '" +
                                 address + "'");
    }
}

void validate_numeric_oid(const std::string& oid, const std::string& context) {
    std::string_view text(oid);
    if (!text.empty() && text.front() == '.') {
        text.remove_prefix(1);
    }
    if (text.empty() || text.back() == '.') {
        throw std::runtime_error(context + ": OID must not be empty");
    }

    unsigned long first_arc = 0;
    unsigned long second_arc = 0;
    std::size_t arc_index = 0;
    while (!text.empty()) {
        const std::size_t separator = text.find('.');
        const std::string_view arc = text.substr(0, separator);
        unsigned long parsed = 0;
        const auto [end, error] =
            std::from_chars(arc.data(), arc.data() + arc.size(), parsed);
        if (arc.empty() || error != std::errc{} ||
            end != arc.data() + arc.size()) {
            throw std::runtime_error(context + ": invalid numeric OID '" +
                                     oid + "'");
        }
        if (arc_index == 0) {
            first_arc = parsed;
        } else if (arc_index == 1) {
            second_arc = parsed;
        }
        ++arc_index;
        if (separator == std::string_view::npos) {
            break;
        }
        text.remove_prefix(separator + 1);
    }
    if (arc_index < 2 || first_arc > 2 ||
        (first_arc < 2 && second_arc > 39)) {
        throw std::runtime_error(context + ": invalid numeric OID '" + oid +
                                 "'");
    }
}

}  // namespace

MonitorConfig JsonConfigRepository::load(const std::string& nodes_path,
                                         const std::string& mibs_path) const {
    JsonOwner nodes_root = read_json(nodes_path);
    JsonOwner mibs_root = read_json(mibs_path);

    MonitorConfig config;
    json_object* nodes = required_array(nodes_root.get(), "nodes", nodes_path);
    const std::size_t node_count = json_object_array_length(nodes);
    if (node_count == 0 || node_count > 500) {
        throw std::runtime_error(nodes_path +
                                 ": node count must be between 1 and 500");
    }
    config.nodes.reserve(node_count);
    for (std::size_t i = 0; i < node_count; ++i) {
        json_object* entry = json_object_array_get_idx(nodes, i);
        const std::string context =
            nodes_path + ": nodes[" + std::to_string(i) + "]";
        if (entry == nullptr ||
            json_object_get_type(entry) != json_type_object) {
            throw std::runtime_error(context + ": expected object");
        }
        NodeConfig node;
        node.address = required_string(entry, "address", context);
        validate_ipv4(node.address, context);

        json_object* community = nullptr;
        if (json_object_object_get_ex(entry, "community", &community)) {
            if (json_object_get_type(community) != json_type_string ||
                json_object_get_string_len(community) == 0) {
                throw std::runtime_error(context +
                                         ": community must be a non-empty string");
            }
            node.community = json_object_get_string(community);
        } else {
            node.community = "public";
        }
        config.nodes.push_back(std::move(node));
    }

    json_object* mibs = required_array(mibs_root.get(), "mibs", mibs_path);
    const std::size_t mib_count = json_object_array_length(mibs);
    if (mib_count == 0) {
        throw std::runtime_error(mibs_path + ": at least one MIB is required");
    }
    config.mibs.reserve(mib_count);
    std::set<std::string> keys;
    for (std::size_t i = 0; i < mib_count; ++i) {
        json_object* entry = json_object_array_get_idx(mibs, i);
        const std::string context =
            mibs_path + ": mibs[" + std::to_string(i) + "]";
        if (entry == nullptr ||
            json_object_get_type(entry) != json_type_object) {
            throw std::runtime_error(context + ": expected object");
        }

        MibDefinition mib;
        mib.key = required_string(entry, "key", context);
        mib.oid = required_string(entry, "oid", context);
        const std::string fault =
            required_string(entry, "fault_level", context);
        if (mib.key.empty() || !keys.insert(mib.key).second) {
            throw std::runtime_error(context +
                                     ": key must be non-empty and unique");
        }
        validate_numeric_oid(mib.oid, context);
        if (fault == "minor") {
            mib.fault_level = FaultLevel::minor;
        } else if (fault == "major") {
            mib.fault_level = FaultLevel::major;
        } else {
            throw std::runtime_error(context +
                                     ": fault_level must be 'minor' or 'major'");
        }
        config.mibs.push_back(std::move(mib));
    }

    return config;
}

}  // namespace snmp_monitor
