# SNMP v2c monitor prototype

Polls up to 500 IPv4 nodes with SNMP v2c `GETBULK` on a five-second schedule.
Each poll cycle issues one request per node concurrently, with one-second
timeouts and no retries. Results are normalized into a JSON key-value snapshot
and published to a POSIX shared-memory object.

The implementation separates domain types and ports from the JSON, Net-SNMP,
and shared-memory adapters. The entry point wires these components together.

## Requirements and build

- C++23 compiler
- Net-SNMP development files and `net-snmp-config`
- json-c development files and `pkg-config`

```sh
make
./snmp_v2c_monitor config/nodes.json config/mibs.json
```

An optional third argument selects the POSIX shared-memory name; the default is
`/snmp_v2c_monitor`. Stop the monitor with Ctrl-C or SIGTERM.

## Configuration

`nodes.json`:

```json
{
  "nodes": [
    { "address": "192.0.2.10", "community": "public" },
    { "address": "192.0.2.11", "community": "monitoring" }
  ]
}
```

`community` is optional and defaults to `public`. SNMP v2c communities are
transmitted without encryption; use a trusted network and restrict access.

`mibs.json`:

```json
{
  "mibs": [
    { "key": "sys_uptime", "oid": "1.3.6.1.2.1.1.3", "fault_level": "minor" },
    { "key": "sys_name", "oid": "1.3.6.1.2.1.1.5", "fault_level": "major" }
  ]
}
```

Use unique keys and numeric OIDs. Configure scalar-object OIDs without the
instance suffix (for example `...1.3`, not `...1.3.0`); the GETBULK request
uses each configured OID as a non-repeater and requests its next instance.
`fault_level` is `minor` (軽故障) or `major` (重故障). This prototype applies
that level when the request fails or the corresponding value is missing; it
does not evaluate thresholds on successfully returned values.

## Shared-memory data

The shared-memory region contains one NUL-terminated JSON snapshot. Its size
grows to fit the configured nodes and values. Example:

```json
{
  "schema_version": 1,
  "nodes": [
    {
      "address": "192.0.2.10",
      "status": "normal",
      "last_checked_unix": 1761350000,
      "error": null,
      "values": {
        "sys_uptime": {
          "value": "Timeticks: (123456) 0:20:34.56",
          "oid": "1.3.6.1.2.1.1.3",
          "fault_level": "minor",
          "status": "normal"
        }
      }
    }
  ]
}
```

For unavailable values, `value` is `null` and `status` is `minor` or `major`.
Readers should take an `fcntl` read lock on the shared-memory file descriptor
before checking its size, mapping, and copying the JSON. The writer takes a
write lock while updating. The object is created with mode `0660`, subject to
the process umask.
