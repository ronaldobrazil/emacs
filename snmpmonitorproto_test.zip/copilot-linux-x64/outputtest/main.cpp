#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cerrno>
#include <charconv>
#include <chrono>
#include <csignal>
#include <cstddef>
#include <cstring>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <thread>

namespace {

constexpr char kDefaultSharedMemory[] = "/snmp_v2c_monitor";
constexpr int kDefaultIntervalSeconds = 5;
volatile std::sig_atomic_t g_running = 1;

void handle_signal(int) {
    g_running = 0;
}

[[noreturn]] void throw_errno(std::string_view operation) {
    throw std::runtime_error(std::string(operation) + ": " +
                             std::strerror(errno));
}

class ReadLock {
public:
    explicit ReadLock(int fd) : fd_(fd) {
        struct flock lock {};
        lock.l_type = F_RDLCK;
        lock.l_whence = SEEK_SET;
        while (fcntl(fd_, F_SETLKW, &lock) == -1) {
            if (errno != EINTR) {
                throw_errno("fcntl read lock");
            }
        }
        locked_ = true;
    }

    ~ReadLock() {
        if (locked_) {
            struct flock lock {};
            lock.l_type = F_UNLCK;
            lock.l_whence = SEEK_SET;
            fcntl(fd_, F_SETLK, &lock);
        }
    }

    ReadLock(const ReadLock&) = delete;
    ReadLock& operator=(const ReadLock&) = delete;

    void unlock() {
        struct flock lock {};
        lock.l_type = F_UNLCK;
        lock.l_whence = SEEK_SET;
        if (fcntl(fd_, F_SETLK, &lock) == -1) {
            throw_errno("fcntl unlock");
        }
        locked_ = false;
    }

private:
    int fd_;
    bool locked_ = false;
};

class Mapping {
public:
    Mapping(void* address, std::size_t size) : address_(address), size_(size) {}
    ~Mapping() {
        if (address_ != MAP_FAILED) {
            munmap(address_, size_);
        }
    }

    Mapping(const Mapping&) = delete;
    Mapping& operator=(const Mapping&) = delete;

    const char* data() const { return static_cast<const char*>(address_); }

    void close() {
        if (munmap(address_, size_) == -1) {
            address_ = MAP_FAILED;
            throw_errno("munmap shared memory");
        }
        address_ = MAP_FAILED;
    }

private:
    void* address_;
    std::size_t size_;
};

std::string read_snapshot(int fd) {
    ReadLock lock(fd);
    struct stat status {};
    if (fstat(fd, &status) == -1) {
        throw_errno("fstat shared memory");
    }
    if (status.st_size <= 0 ||
        static_cast<std::uintmax_t>(status.st_size) >
            std::numeric_limits<std::size_t>::max()) {
        throw std::runtime_error("shared-memory object has invalid size");
    }

    const auto size = static_cast<std::size_t>(status.st_size);
    void* address =
        mmap(nullptr, size, PROT_READ, MAP_SHARED, fd, 0);
    if (address == MAP_FAILED) {
        throw_errno("mmap shared memory");
    }
    Mapping mapping(address, size);
    const char* terminator =
        static_cast<const char*>(std::memchr(mapping.data(), '\0', size));
    if (terminator == nullptr) {
        throw std::runtime_error(
            "shared-memory snapshot is not NUL-terminated");
    }
    std::string snapshot(mapping.data(),
                         static_cast<std::size_t>(terminator - mapping.data()));
    mapping.close();
    lock.unlock();
    return snapshot;
}

bool valid_name(std::string_view name) {
    return name.size() > 1 && name.front() == '/' &&
           name.find('/', 1) == std::string_view::npos;
}

int parse_interval(std::string_view text) {
    int interval = 0;
    const auto [end, error] =
        std::from_chars(text.data(), text.data() + text.size(), interval);
    if (error != std::errc{} || end != text.data() + text.size() ||
        interval <= 0) {
        throw std::invalid_argument("interval must be a positive integer");
    }
    return interval;
}

}  // namespace

int main(int argc, char* argv[]) {
    if (argc > 3) {
        std::cerr << "Usage: " << argv[0]
                  << " [shared-memory-name] [interval-seconds]\n";
        return 2;
    }

    const std::string name = argc >= 2 ? argv[1] : kDefaultSharedMemory;
    if (!valid_name(name)) {
        std::cerr << "Shared-memory name must start with '/' and contain no "
                     "other '/'\n";
        return 2;
    }

    int interval_seconds = kDefaultIntervalSeconds;
    try {
        if (argc == 3) {
            interval_seconds = parse_interval(argv[2]);
        }
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 2;
    }

    const int fd = shm_open(name.c_str(), O_RDONLY, 0);
    if (fd == -1) {
        std::cerr << "shm_open: " << std::strerror(errno) << '\n';
        return 1;
    }

    std::signal(SIGINT, handle_signal);
    std::signal(SIGTERM, handle_signal);
    const auto interval = std::chrono::seconds(interval_seconds);
    auto next_read = std::chrono::steady_clock::now();

    while (g_running != 0) {
        try {
            const std::string snapshot = read_snapshot(fd);
            if (snapshot.empty()) {
                std::cerr << "No snapshot has been published yet\n";
            } else {
                std::cout << snapshot << '\n' << std::flush;
            }
        } catch (const std::exception& error) {
            std::cerr << "Unable to read shared-memory snapshot: "
                      << error.what() << '\n';
        }

        next_read += interval;
        const auto now = std::chrono::steady_clock::now();
        while (next_read <= now) {
            next_read += interval;
        }
        std::this_thread::sleep_until(next_read);
    }

    close(fd);
    return 0;
}
